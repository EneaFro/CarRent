CREATE TABLE IF NOT EXISTS users (
    email TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    cognome TEXT NOT NULL,
    password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
    email TEXT PRIMARY KEY,
    password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cars (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    classe TEXT NOT NULL,
    costo_per_giorno REAL NOT NULL,
    consumo REAL NOT NULL,
    posti INTEGER NOT NULL,
    cambio TEXT NOT NULL,
    immagine TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_email TEXT NOT NULL,
    car_id INTEGER NOT NULL,
    luogo_ritiro TEXT NOT NULL,
    data_ritiro DATE NOT NULL,
    ora_ritiro TIME NOT NULL,
    luogo_rilascio TEXT NOT NULL,
    data_rilascio DATE NOT NULL,
    ora_rilascio TIME NOT NULL,
    pagamento INTEGER NOT NULL,
    FOREIGN KEY (user_email) REFERENCES users (email),
    FOREIGN KEY (car_id) REFERENCES cars (id)
);

CREATE TABLE IF NOT EXISTS recensioni (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_email TEXT NOT NULL,
    contenuto TEXT NOT NULL,
    FOREIGN KEY (user_email) REFERENCES users (email), 
);




