
let deleteBookingId = null;
function filterBookings() {
    const filter = document.getElementById('filter-select').value;
    const today = new Date().toISOString().split('T')[0];
    const bookings = document.querySelectorAll('.booking');

    bookings.forEach(booking => {
        const dataRitiro = booking.querySelector('.data-ritiro').innerText;
        if (filter === 'all') {
            booking.style.display = 'block';
        } else if (filter === 'today' && dataRitiro === today) {
            booking.style.display = 'block';
        } else if (filter === 'past' && dataRitiro < today) {
            booking.style.display = 'block';
        } else if (filter === 'future' && dataRitiro > today) {
            booking.style.display = 'block';
        } else {
            booking.style.display = 'none';
        }
    });
}

function showAccount() {
    fetch('/api/user-info')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('user-email').innerText = data.user.email;
                document.getElementById('user-nome').innerText = data.user.nome;
                document.getElementById('user-cognome').innerText = data.user.cognome;

                const bookingsList = document.getElementById('bookings-list');
                bookingsList.innerHTML = '';
                data.bookings.forEach(booking => {
                    const bookingDiv = document.createElement('div');
                    bookingDiv.className = 'booking';
                    bookingDiv.innerHTML = `
                        <p><strong>Auto ID:</strong> ${booking.car_id}</p>
                        <p><strong>Luogo Ritiro:</strong> ${booking.luogo_ritiro}</p>
                        <p class="data-ritiro"><strong>Data Ritiro:</strong> ${booking.data_ritiro}</p>
                        <p><strong>Ora Ritiro:</strong> ${booking.ora_ritiro}</p>
                        <p><strong>Luogo Rilascio:</strong> ${booking.luogo_rilascio}</p>
                        <p><strong>Data Rilascio:</strong> ${booking.data_rilascio}</p>
                        <p><strong>Ora Rilascio:</strong> ${booking.ora_rilascio}</p>
                        <button onclick="confirmDeleteBooking(${booking.id})" class="delete-booking-button">Elimina</button>
                    `;
                    bookingsList.appendChild(bookingDiv);
                });

                // Apply the filter after loading the bookings
                filterBookings();
            } else {
                showAlert('Errore nel recupero delle informazioni utente.');
            }
        })
        .catch(error => {
            console.error('Errore:', error);
            showAlert('Errore nel recupero delle informazioni utente.');
        });
}



function confirmDeleteBooking(bookingId) {
    deleteBookingId = bookingId;
    const modal = document.getElementById('confirm-delete-modal');
    modal.style.display = 'block';
}

document.getElementById('confirm-delete-btn').addEventListener('click', function() {
    if (deleteBookingId !== null) {
        fetch(`/api/bookings/${deleteBookingId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert('Prenotazione eliminata con successo.');
                showAccount();
            } else {
                showAlert('Errore durante l\'eliminazione della prenotazione.');
            }
            deleteBookingId = null;
            closeModal();
        })
        .catch(error => {
            console.error('Errore:', error);
            showAlert('Errore durante l\'eliminazione della prenotazione.');
            deleteBookingId = null;
            closeModal();
        });
    }
});

function editUserInfo() {
    document.getElementById('user-section').style.display = 'none';
    document.getElementById('edit-user-section').style.display = 'block';

    fetch('/api/user-info')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('edit-email').value = data.user.email;
                document.getElementById('edit-nome').value = data.user.nome;
                document.getElementById('edit-cognome').value = data.user.cognome;
            }
        })
        .catch(error => {
            console.error('Errore nel recupero delle informazioni utente:', error);
            showAlert('Errore nel recupero delle informazioni utente.');
        });
}

function cancelEdit() {
    document.getElementById('edit-user-section').style.display = 'none';
    document.getElementById('user-section').style.display = 'block';
}

document.getElementById('edit-user-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    fetch('/api/user-info', {
        method: 'PUT',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAccount();
            showAlert('Informazioni utente aggiornate con successo.');
        } else {
            showAlert('Errore durante l\'aggiornamento delle informazioni utente.');
        }
    })
    .catch(error => {
        console.error('Errore:', error);
        showAlert('Errore durante l\'aggiornamento delle informazioni utente.');
    });
});

function logout() {
    fetch('/api/logout', {
        method: 'POST'
    }).then(response => {
        if (response.ok) {
            window.location.href = 'index.html';
        } else {
           showAlert('Errore durante il logout.');
        }
    }).catch(error => {
        console.error('Errore durante il logout:', error);
        showAlert('Errore durante il logout.');
    });
}

function showAlert(message) {
    const modal = document.getElementById('alert-modal');
    const modalMessage = document.getElementById('modal-message');
    modalMessage.innerText = message;
    modal.style.display = 'block';
}

function closeModal() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => modal.style.display = 'none');
}

document.addEventListener('DOMContentLoaded', () => {
    checkLoginStatus();
});

function checkLoginStatus() {
    fetch('/api/check-login')
        .then(response => response.json())
        .then(data => {
            if (!data.loggedIn) {
                window.location.href = '/login.html';
            } else {
                showAccount();
            }
        })
        .catch(error => {
            console.error('Errore durante il controllo dello stato di login:', error);
            showAlert('Errore durante il controllo dello stato di login.');
        });
}
