document.addEventListener('DOMContentLoaded', () => {
    // Imposta la data minima per gli input di tipo date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pick-up-date').setAttribute('min', today);
    document.getElementById('drop-off-date').setAttribute('min', today);

    // Imposta l'ora minima per gli input di tipo time
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const currentTime = `${hours}:${minutes}`;
    document.getElementById('pick-up-time').setAttribute('min', currentTime);
    document.getElementById('drop-off-time').setAttribute('min', currentTime);
});
let initialSearchResults = [];

function searchCars() {
    const pickUpAddress = document.getElementById('pick-up-address').value;
    const pickUpDate = document.getElementById('pick-up-date').value;
    const pickUpTime = document.getElementById('pick-up-time').value;
    const dropOffAddress = document.getElementById('drop-off-address').value;
    const dropOffDate = document.getElementById('drop-off-date').value;
    const dropOffTime = document.getElementById('drop-off-time').value;

    const searchData = {
        pickUpAddress,
        pickUpDate,
        pickUpTime,
        dropOffAddress,
        dropOffDate,
        dropOffTime
    };

    fetch('/api/search-cars', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(searchData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const carItemBox = document.getElementById('car-item-box');
            carItemBox.innerHTML = '';
            initialSearchResults = data.cars; // Salva i risultati iniziali della ricerca
            data.cars.forEach(car => {
                const carItem = document.createElement('div');
                carItem.classList.add('car-item');
                carItem.innerHTML = `
                <div class="car-name">${car.nome}</div>
                    <div class="car-body-category">${car.classe}</div>
                    <div class="price">$<p>${car.costo_per_giorno}</p><span>/giorno</span></div>
                    <div class="car-image"><img src="/images/${car.immagine}" alt="${car.nome}"></div>
                    <div class="bottom-content">
                        <div class="car-feature">
                            <div class="feature-item">
                                <i class="fa-solid fa-gears"></i>
                                <span>${car.cambio}</span>
                            </div>
                            <div class="feature-item">
                                <i class="fa-solid fa-chair"></i>
                                <span>${car.posti} posti</span>
                            </div>
                            <div class="feature-item">
                                <i class="fa-solid fa-pump"></i>
                                <span>${car.consumo} KM/L</span>
                            </div>
                        </div>
                        <button onclick="rentCar(${car.id})" class="rent-button">
                            noleggia<i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                `;
                carItemBox.appendChild(carItem);
            });
        } else {
            console.error('Errore durante la ricerca delle auto:', data.message);
        }
    })
    .catch(error => {
        console.error('Errore durante la ricerca delle auto:', error);
    });
}

function filterCars() {
    const selectedClasses = Array.from(document.querySelectorAll('input[name="class"]:checked')).map(cb => cb.value);
    const selectedCapacity = Array.from(document.querySelectorAll('input[name="capacity"]:checked')).map(cb => cb.value);
    const selectedEngine = Array.from(document.querySelectorAll('input[name="engine"]:checked')).map(cb => cb.value);

    let filteredCars = initialSearchResults;

    if (selectedClasses.length > 0) {
        filteredCars = filteredCars.filter(car => selectedClasses.includes(car.classe));
    }
    if (selectedCapacity.length > 0) {
        filteredCars = filteredCars.filter(car => selectedCapacity.includes(car.posti.toString()));
    }
    if (selectedEngine.length > 0) {
        filteredCars = filteredCars.filter(car => selectedEngine.includes(car.cambio));
    }

    const carItemBox = document.getElementById('car-item-box');
    carItemBox.innerHTML = '';
    filteredCars.forEach(car => {
        const carItem = document.createElement('div');
        carItem.classList.add('car-item');
        carItem.innerHTML = `
        <div class="car-name">${car.nome}</div>
            <div class="car-body-category">${car.classe}</div>
            <div class="price">$<p>${car.costo_per_giorno}</p><span>/day</span></div>
            <div class="car-image"><img src="/images/${car.immagine}" alt="${car.nome}"></div>
            <div class="bottom-content">
                <div class="car-feature">
                    <div class="feature-item">
                        <i class="fa-solid fa-gears"></i>
                        <span>${car.cambio}</span>
                    </div>
                    <div class="feature-item">
                        <i class="fa-solid fa-chair"></i>
                        <span>${car.posti} posti</span>
                    </div>
                    <div class="feature-item">
                        <i class="fa-solid fa-pump"></i>
                        <span>${car.consumo} KM/L</span>
                    </div>
                </div>
                <button onclick="rentCar(${car.id})" class="rent-button">
                    noleggia<i class="fa-solid fa-arrow-right"></i>
                </button>
            </div>
        `;
        carItemBox.appendChild(carItem);
    });
}

function rentCar(carId) {
    const user_email = 'utente@example.com'; // Sostituisci con l'email dell'utente loggato
    const luogo_ritiro = document.getElementById('pick-up-address').value;
    const data_ritiro = document.getElementById('pick-up-date').value;
    const ora_ritiro = document.getElementById('pick-up-time').value;
    const luogo_rilascio = document.getElementById('drop-off-address').value;
    const data_rilascio = document.getElementById('drop-off-date').value;
    const ora_rilascio = document.getElementById('drop-off-time').value;
    const pagamento = 1; // Sostituisci con il valore effettivo del pagamento

    const bookingData = {
        user_email,
        car_id: carId,
        luogo_ritiro,
        data_ritiro,
        ora_ritiro,
        luogo_rilascio,
        data_rilascio,
        ora_rilascio,
        pagamento
    };

    fetch('/api/book-car', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookingData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Prenotazione effettuata con successo!');
            window.location.href = 'Conferma.html';
        } else {
            showAlert('Errore durante la prenotazione: ' + data.message);
            window.location.href = 'Errore.html';
        }
    })
    .catch(error => {
        console.error('Errore durante la prenotazione:', error);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);

    document.getElementById('pick-up-address').value = params.get('pickUpAddress') || '';
    document.getElementById('pick-up-date').value = params.get('pickUpDate') || '';
    document.getElementById('pick-up-time').value = params.get('pickUpTime') || '';
    document.getElementById('drop-off-address').value = params.get('dropOffAddress') || '';
    document.getElementById('drop-off-date').value = params.get('dropOffDate') || '';
    document.getElementById('drop-off-time').value = params.get('dropOffTime') || '';

    if (params.toString()) {
        searchCars();
    }
});

function logout() {
    fetch('/api/logout', {
        method: 'POST'
    }).then(response => {
        if (response.ok) {
            response.json().then(data => {
                console.log(`User ${data.email} has logged out`);
                window.location.href = 'index.html';
            });
        } else {
            showAlert('Errore durante il logout');
        }
    }).catch(error => {
        console.error('Errore durante il logout:', error);
    });
}

function handleSearch(event) {
    event.preventDefault();

    const pickUpAddress = document.getElementById('pick-up-address').value;
    const pickUpDate = document.getElementById('pick-up-date').value;
    const pickUpTime = document.getElementById('pick-up-time').value;
    const dropOffAddress = document.getElementById('drop-off-address').value;
    const dropOffDate = document.getElementById('drop-off-date').value;
    const dropOffTime = document.getElementById('drop-off-time').value;

    const params = new URLSearchParams({
        pickUpAddress,
        pickUpDate,
        pickUpTime,
        dropOffAddress,
        dropOffDate,
        dropOffTime
    });

    window.location.href = `Noleggia.html?${params.toString()}`;
}
document.addEventListener('DOMContentLoaded', (event) => {
    fetch('/api/check-login')
        .then(response => response.json())
        .then(data => {
            const accountBox = document.getElementById('account-box');
            if (data.loggedIn) {
                accountBox.innerHTML = `
                    <button onclick="showAccount()" class="box account-bar">
                        <p>Account</p>
                        <i class="fa-solid fa-user"></i>
                    </button>
                    <button onclick="logout()" class="box login-bar">
                        <p>Esci</p>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                `;
                document.querySelector('a[href="Errore.html"]').href = "Noleggia.html";
                document.querySelector('a[href="Errore.html"]').href = "Catalogo.html";
            } else {
                accountBox.innerHTML = `
                    <button onclick="window.location.href='login.html'" class="box login-bar">
                        <p>Login</p>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                    <button onclick="window.location.href='register.html'" class="box account-bar">
                        <p>Registrati</p>
                        <i class="fa-solid fa-user-plus"></i>
                    </button>
                `;
            }
        })
        .catch(error => console.error('Errore:', error));
});