document.addEventListener('DOMContentLoaded', () => {
    // Imposta la data minima per gli input di tipo date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pick-up-date').setAttribute('min', today);
    document.getElementById('drop-off-date').setAttribute('min', today);

    // Imposta l'ora minima per gli input di tipo time
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const currentTime = `${hours}:${minutes}`;
    document.getElementById('pick-up-time').setAttribute('min', currentTime);
    document.getElementById('drop-off-time').setAttribute('min', currentTime);
});
function showPopup() {
    document.getElementById('success-popup').style.display = 'flex';
}

function closePopup(redirectUrl) {
    window.location.href = redirectUrl;
}
 document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const carId = urlParams.get('carId');

    fetch(`/api/get-car?id=${carId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayCar(data.car);
        } else {
            showErrorPopup('Errore durante il recupero dei dettagli dell\'auto: ' + data.message);
        }
    })
    .catch(error => showErrorPopup('Errore di rete: ' + error));
});

function displayCar(car) {
    const container = document.getElementById('car-container');
    container.innerHTML = `
        <div class="car-item">
            <div class="car-name">${car.nome}</div>
            <div class="car-body-category">${car.classe}</div>
            <div class="price">${car.costo_per_giorno} €/giorno</div>
            <div class="car-image"><img src="/images/${car.immagine}" alt="${car.nome}"></div>
            <div class="bottom-content">
                <div class="car-feature">
                    <div class="feature-item">
                        <i class="fa-solid fa-gears"></i>
                        <span>${car.cambio}</span>
                    </div>
                    <div class="feature-item">
                        <i class="fa-solid fa-chair"></i>
                        <span>${car.posti} posti</span>
                    </div>
                    <div class="feature-item">
                        <i class="fa-solid fa-pump"></i>
                        <span>${car.consumo} KM/L</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function bookCar() {
    const carId = new URLSearchParams(window.location.search).get('carId');
    const pickUpAddress = document.getElementById('pick-up-address').value;
    const pickUpDate = document.getElementById('pick-up-date').value;
    const pickUpTime = document.getElementById('pick-up-time').value;
    const dropOffAddress = document.getElementById('drop-off-address').value;
    const dropOffDate = document.getElementById('drop-off-date').value;
    const dropOffTime = document.getElementById('drop-off-time').value;

    if (!pickUpAddress || !pickUpDate || !pickUpTime || !dropOffAddress || !dropOffDate || !dropOffTime) {
        alert('Devi compilare tutti i campi del form per poter prenotare un\'auto.');
        return;
    }

    const bookingData = {
        car_id: carId,
        luogo_ritiro: pickUpAddress,
        data_ritiro: pickUpDate,
        ora_ritiro: pickUpTime,
        luogo_rilascio: dropOffAddress,
        data_rilascio: dropOffDate,
        ora_rilascio: dropOffTime
    };

    fetch('/api/check-availability', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookingData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.available) {
            fetch('/api/book-car', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(bookingData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                   
                    window.location.href = 'Conferma.html';
                } else {
                    alert('Errore durante la prenotazione: ' + data.message);
                }
            })
            .catch(error => console.error('Errore durante la prenotazione:', error));
        } else {
            showAlert('L\'auto non è disponibile per le date e orari selezionati.');
        }
    })
    .catch(error => console.error('Errore durante la verifica della disponibilità:', error));
}
document.addEventListener('DOMContentLoaded', (event) => {
    fetch('/api/check-login')
        .then(response => response.json())
        .then(data => {
            const accountBox = document.getElementById('account-box');
            if (data.loggedIn) {
                accountBox.innerHTML = `
                    <button onclick="window.location.href='Account.html'" class="box account-bar">
                        <p>Account</p>
                        <i class="fa-solid fa-user"></i>
                    </button>
                    <button onclick="logout()" class="box login-bar">
                        <p>Esci</p>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                `;
            } else {
                accountBox.innerHTML = `
                    <button onclick="window.location.href='login.html'" class="box login-bar">
                        <p>Login</p>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                    <button onclick="window.location.href='register.html'" class="box account-bar">
                        <p>Registrati</p>
                        <i class="fa-solid fa-user-plus"></i>
                    </button>
                `;
            }
        })
        .catch(error => console.error('Errore:', error));
});