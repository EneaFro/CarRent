// Funzione per caricare le recensioni
function loadReviews() {
    fetch('/api/reviews')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const reviewsList = document.getElementById('reviewsList');
                reviewsList.innerHTML = '';
                data.reviews.forEach(review => {
                    const reviewItem = document.createElement('div');
                    reviewItem.classList.add('review-item');
                    reviewItem.innerHTML = `
                    <img src="../images/user.png" alt="Avatar" <div class="review-author"><strong> ${review.user_email}: </strong></div>
                    
                        <div class="review-text">${review.contenuto}</div>
                        
                    `;
                    reviewsList.appendChild(reviewItem);
                });
            } else {
                console.error('Errore durante il recupero delle recensioni:', data.message);
            }
        })
        .catch(error => {
            console.error('Errore durante il recupero delle recensioni:', error);
        });
}

// Funzione per aggiungere una nuova recensione e inviarla al backend
function addReview() {
    var name = document.getElementById("name").value;
    var review = document.getElementById("review").value;

    var reviewDiv = document.createElement("div");
    reviewDiv.classList.add("review-item");
    reviewDiv.innerHTML = `
        <div class="review-author"><strong>${name}</strong></div>
        <div class="review-text">${review}</div>
        
    `;

    document.getElementById("reviewsList").appendChild(reviewDiv);

    const reviewData = {
        user_email: name,
        contenuto: review
    };

    fetch('/api/reviews', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(reviewData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Recensione aggiunta con successo!');
        } else {
            showAlert('Errore durante l\'aggiunta della recensione: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Errore durante l\'aggiunta della recensione:', error);
    });

    // Resetta i campi del modulo
    document.getElementById("addReviewForm").reset();
}

// Aggiungi un evento di ascolto al modulo di invio recensioni
document.getElementById("addReviewForm").addEventListener("submit", function(event) {
    event.preventDefault();
    addReview();
});

// Carica le recensioni al caricamento della pagina
document.addEventListener('DOMContentLoaded', () => {
    loadReviews();
});