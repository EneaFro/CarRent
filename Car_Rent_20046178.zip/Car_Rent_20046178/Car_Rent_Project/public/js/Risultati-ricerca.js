function showAlert(message) {
    document.getElementById('modal-message').innerText = message;
    document.getElementById('alert-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('alert-modal').style.display = 'none';
}
let searchResults = [];

document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('search');

    fetch(`/api/search-carss?query=${encodeURIComponent(searchQuery)}`)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            searchResults = data.cars;
            displayCars(data.cars);
        } else {
            console.error('Error fetching cars:', data.message);
        }
    })
    .catch(error => console.error('Fetch error:', error));
});

function displayCars(cars) {
    const container = document.getElementById('car-item-box');
    const noResults = document.getElementById('no-results');
    container.innerHTML = ''; // Clear previous results
    if (cars.length === 0) {
        noResults.style.display = 'flex';
    } else {
        noResults.style.display = 'none';
        cars.forEach(car => {
            const carElement = document.createElement('div');
            carElement.className = 'car-item';
            carElement.innerHTML = `
                <div class="car-name">${car.nome}</div>
                <div class="car-body-category">${car.classe}</div>
                <div class="price">${car.costo_per_giorno} €/giorno</div>
                <div class="car-image"><img src="/images/${car.immagine}" alt="${car.nome}"></div>
                <div class="bottom-content">
                    <div class="car-feature">
                        <div class="feature-item">
                            <i class="fa-solid fa-gears"></i>
                            <span>${car.cambio}</span>
                        </div>
                        <div class="feature-item">
                            <i class="fa-solid fa-chair"></i>
                            <span>${car.posti} posti</span>
                        </div>
                        <div class="feature-item">
                            <i class="fa-solid fa-pump"></i>
                            <span>${car.consumo} KM/L</span>
                        </div>
                    </div>
                    <button onclick="redirectToPrenotazione(${car.id})" class="rent-button">
                        noleggia<i class="fa-solid fa-arrow-right"></i>
                    </button>
                </div>
            `;
            container.appendChild(carElement);
        });
    }
}

function redirectToPrenotazione(carId) {
    fetch('/api/check-login')
        .then(response => response.json())
        .then(data => {
            if (data.loggedIn) {
                window.location.href = `Prenotazione.html?carId=${carId}`;
            } else {
                showAlert('Devi essere loggato per noleggiare un\'auto.');
            }
        })
        .catch(error => console.error('Error checking login status:', error));
}