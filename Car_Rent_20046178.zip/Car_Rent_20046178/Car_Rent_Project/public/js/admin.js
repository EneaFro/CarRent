
        document.addEventListener('DOMContentLoaded', function() {
            loadBookings();
            loadCars();
            loadAdmins();
        });
    
        function openTab(event, tabName) {
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
    
            const tabButtons = document.querySelectorAll('.tab');
            tabButtons.forEach(button => button.classList.remove('active'));
            event.currentTarget.classList.add('active');
        }
    
        function openAddBookingForm() {
            document.getElementById('add-booking-form').style.display = 'block';
        }
    
        function closeAddBookingForm() {
            document.getElementById('add-booking-form').style.display = 'none';
        }
    
        function openEditBookingForm(booking) {
            document.getElementById('edit_booking_id').value = booking.id;
            document.getElementById('edit_user_email').value = booking.user_email;
            document.getElementById('edit_car_id').value = booking.car_id;
            document.getElementById('edit_luogo_ritiro').value = booking.luogo_ritiro;
            document.getElementById('edit_data_ritiro').value = booking.data_ritiro;
            document.getElementById('edit_ora_ritiro').value = booking.ora_ritiro;
            document.getElementById('edit_luogo_rilascio').value = booking.luogo_rilascio;
            document.getElementById('edit_data_rilascio').value = booking.data_rilascio;
            document.getElementById('edit_ora_rilascio').value = booking.ora_rilascio;
            document.getElementById('edit-booking-form').style.display = 'block';
        }
    
        function closeEditBookingForm() {
            document.getElementById('edit-booking-form').style.display = 'none';
        }
    
        function openAddCarForm() {
            document.getElementById('add-car-form').style.display = 'block';
        }
    
        function closeAddCarForm() {
            document.getElementById('add-car-form').style.display = 'none';
        }
    
        
    
        function openAddAdminForm() {
            document.getElementById('add-admin-form').style.display = 'block';
        }
    
        function closeAddAdminForm() {
            document.getElementById('add-admin-form').style.display = 'none';
        }
    
        function showSuccessPopup(message) {
            showAlert(message);
        }
    
        function showErrorPopup(message) {
            showAlert(message);
        }
    
        function closePopup(popupId) {
            document.getElementById(popupId).style.display = 'none';
        }
    
        function loadBookings() {
    const filter = document.getElementById('booking-filter').value;

    fetch('/api/bookings')
        .then(response => response.json())
        .then(data => {
            const bookingsTableBody = document.getElementById('bookings-table-body');
            bookingsTableBody.innerHTML = '';
            const today = new Date().toISOString().split('T')[0];

            let filteredBookings = data.bookings;

            if (filter === 'today') {
                filteredBookings = filteredBookings.filter(booking => booking.data_ritiro === today);
            } else if (filter === 'past') {
                filteredBookings = filteredBookings.filter(booking => booking.data_ritiro < today);
            } else if (filter === 'future') {
                filteredBookings = filteredBookings.filter(booking => booking.data_ritiro > today);
            }

            filteredBookings.forEach(booking => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${booking.id}</td>
                    <td>${booking.user_email}</td>
                    <td>${booking.car_id}</td>
                    <td>${booking.luogo_ritiro}</td>
                    <td>${booking.data_ritiro}</td>
                    <td>${booking.ora_ritiro}</td>
                    <td>${booking.luogo_rilascio}</td>
                    <td>${booking.data_rilascio}</td>
                    <td>${booking.ora_rilascio}</td>
                `;
                bookingsTableBody.appendChild(row);
            });
        })
        .catch(error => showErrorPopup('Errore durante il caricamento delle prenotazioni'));
}
    
        function loadCars() {
            fetch('/api/cars')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const carsTableBody = document.getElementById('cars-table-body');
                        carsTableBody.innerHTML = '';
                        data.cars.forEach(car => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${car.id}</td>
                                <td>${car.nome}</td>
                                <td>${car.classe}</td>
                                <td>${car.costo_per_giorno}</td>
                                <td>${car.consumo}</td>
                                <td>${car.posti}</td>
                                <td>${car.cambio}</td>
                                <td><img src="/images/${car.immagine}" alt="${car.nome}" width="100"></td>
                                <td>
                                    
                                    <button class="add-button" onclick='deleteCar(${car.id})'>Delete</button>
                                </td>
                            `;
                            carsTableBody.appendChild(row);
                        });
                    } else {
                        showErrorPopup(data.message);
                    }
                })
                .catch(error => showErrorPopup('Error loading cars.'));
        }
    
        function submitBookingForm(event) {
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
    
            fetch('/api/bookings', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessPopup(data.message);
                    loadBookings();
                    closeAddBookingForm();
                    closeEditBookingForm();
                } else {
                    showErrorPopup(data.message);
                }
            })
            .catch(error => showErrorPopup('Errore durante l\'aggiunta della prenotazione'));
        }
    
        function submitCarForm(event) {
            event.preventDefault();
            const form = document.getElementById('addCarForm');
            const formData = new FormData(form);
    
            fetch('/api/cars', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessPopup('Macchina aggiunta con successo!');
                    form.reset();
                    closeAddCarForm();
                    loadCars();
                } else {
                    showErrorPopup(data.message || 'Errore durante l\'aggiunta della macchina.');
                }
            })
            .catch(error => {
                showErrorPopup('Errore durante l\'aggiunta della macchina.');
                console.error('Errore:', error);
            });
        }
    
        



        function deleteBooking(bookingId) {
            fetch(`/api/bookings/${bookingId}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessPopup(data.message);
                    loadBookings();
                } else {
                    showErrorPopup(data.message);
                }
            })
            .catch(error => showErrorPopup('Errore durante la cancellazione della prenotazione'));
        }
    
        function deleteCar(carId) {
            fetch(`/api/cars/${carId}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessPopup(data.message);
                    loadCars();
                } else {
                    showErrorPopup(data.message);
                }
            })
            .catch(error => showErrorPopup('Errore durante la cancellazione della macchina'));
        }
    
        function submitAdminForm(event) {
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
    
            fetch('/api/admins', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessPopup(data.message);
                    loadAdmins();
                    closeAddAdminForm();
                } else {
                    showErrorPopup(data.message);
                }
            })
            .catch(error => showErrorPopup('Errore durante l\'aggiunta dell\'admin'));
        }
    
        function loadAdmins() {
            fetch('/api/admins')
                .then(response => response.json())
                .then(data => {
                    const adminsTableBody = document.getElementById('admins-table-body');
                    adminsTableBody.innerHTML = '';
                    data.admins.forEach(admin => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${admin.email}</td>
                            <td>${admin.password}</td>
                            <td>
                                <button class="add-button" onclick='deleteAdmin("${admin.email}")'>Delete</button>
                            </td>
                        `;
                        adminsTableBody.appendChild(row);
                    });
                })
                .catch(error => showErrorPopup('Errore durante il caricamento degli admin'));
        }
    
        function deleteAdmin(adminEmail) {
            fetch(`/api/admins/${adminEmail}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessPopup(data.message);
                    loadAdmins();
                } else {
                    showErrorPopup(data.message);
                }
            })
            .catch(error => showErrorPopup('Errore durante la cancellazione dell\'admin'));
        }
    