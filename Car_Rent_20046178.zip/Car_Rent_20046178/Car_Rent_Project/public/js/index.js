document.addEventListener('DOMContentLoaded', () => {
    // Imposta la data minima per gli input di tipo date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pick-up-date').setAttribute('min', today);
    document.getElementById('drop-off-date').setAttribute('min', today);

    // Imposta l'ora minima per gli input di tipo time
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const currentTime = `${hours}:${minutes}`;
    document.getElementById('pick-up-time').setAttribute('min', currentTime);
    document.getElementById('drop-off-time').setAttribute('min', currentTime);
});
function handleSearch(event) {
    event.preventDefault();

    const pickUpAddress = document.getElementById('pick-up-address').value;
    const pickUpDate = document.getElementById('pick-up-date').value;
    const pickUpTime = document.getElementById('pick-up-time').value;
    const dropOffAddress = document.getElementById('drop-off-address').value;
    const dropOffDate = document.getElementById('drop-off-date').value;
    const dropOffTime = document.getElementById('drop-off-time').value;

    const params = new URLSearchParams({
        pickUpAddress,
        pickUpDate,
        pickUpTime,
        dropOffAddress,
        dropOffDate,
        dropOffTime
    });

    window.location.href = `noleggia.html?${params.toString()}`;
}