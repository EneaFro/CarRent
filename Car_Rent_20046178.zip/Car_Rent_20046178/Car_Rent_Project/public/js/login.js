document.addEventListener('DOMContentLoaded', function() {
    const showAlert = (message) => {
        document.getElementById('modal-message').innerText = message;
        document.getElementById('alert-modal').style.display = 'block';
    };

    const loginForm = document.getElementById('login-form');
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(loginForm);
        fetch('/login', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json().then(data => ({ status: response.status, data })))
        .then(({ status, data }) => {
            if (status === 200 && data.success) {
                document.getElementById('modal-message').innerText = 'Login effettuato con successo!';
                document.getElementById('modal-ok-btn').onclick = () => {
                    window.location.href = data.redirectUrl;
                };
                document.getElementById('alert-modal').style.display = 'block';
            } else {
                showAlert('Username o password errati');
                document.getElementById('modal-ok-btn').onclick = () => {
                    window.location.href = '/login.html';
                };
            }
        })
        .catch(error => {
            showAlert('Errore nel login');
        });
    });
});

