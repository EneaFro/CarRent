document.getElementById('register-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    fetch('/api/register', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('modal-message').innerText = 'Registrazione effettuata con successo!';
            document.getElementById('modal-ok-btn').onclick = () => {
                window.location.href = '/index.html';
            };
        } else {
            document.getElementById('modal-message').innerText = data.message || 'Errore durante la registrazione';
            document.getElementById('modal-ok-btn').onclick = () => {
                closeModal();
            };
        }
        document.getElementById('alert-modal').style.display = 'block';
    })
    .catch(error => {
        document.getElementById('modal-message').innerText = 'Errore durante la registrazione';
        document.getElementById('modal-ok-btn').onclick = () => {
            closeModal();
        };
        document.getElementById('alert-modal').style.display = 'block';
    });
});

function closeModal() {
    document.getElementById('alert-modal').style.display = 'none';
}