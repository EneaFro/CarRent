
const showButton = document.querySelectorAll(".show-button");

showButton.forEach((btn) => {
    btn.addEventListener("click", function() {
        this.parentElement.parentElement.classList.toggle('show')
    })
});

/*function logout() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "index.html";
}*/
function apriIndex() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "index.html";
}
function apriNoleggia() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "Noleggia.html";
}
function apriAccount() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "Account.html";
}
function errore() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "Errore.html";
}

function apriPagina() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "Prenotazione.html";
}
function apriLogin() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "login.html";
} 
function apriLoginAdmin() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "login-admin.html";
}
function apriScelta() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "scelta.html";
}
function apriRegister() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "register.html";
}

function accedi() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "indexLoggato.html";
}

function recensione() {
    // Modifica l'URL con l'indirizzo della pagina che vuoi aprire
    window.location.href = "Recensione.html";
}
//menu button
const menuButton = document.querySelector(".menu-toggle"),
navItem=document.querySelector(".nav-item");

function togglemenu(){
    menuButton.classList.toggle('show');
    navItem.classList.toggle("show");
}

window.onscroll = () => {
    menuButton.classList.remove('show');
    navItem.classList.remove("show");
}




document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('search-button');
    const carListElement = document.getElementById('car-list');

    searchButton.addEventListener('click', () => {
        const pickupLocation = document.getElementById('pickup-location').value;
        const pickupDate = document.getElementById('pickup-date').value;
        const pickupTime = document.getElementById('pickup-time').value;
        const dropoffLocation = document.getElementById('dropoff-location').value;
        const dropoffDate = document.getElementById('dropoff-date').value;
        const dropoffTime = document.getElementById('dropoff-time').value;

        const searchParams = {
            pickupLocation,
            pickupDate,
            pickupTime,
            dropoffLocation,
            dropoffDate,
            dropoffTime,
        };

        fetch('/api/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(searchParams)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayCars(carListElement, data.cars);
            } else {
                alert('Nessuna auto disponibile per le date selezionate.');
            }
        });
    });

    function displayCars(carListElement, cars) {
        carListElement.innerHTML = '';
        cars.forEach(car => {
            const carItem = document.createElement('div');
            carItem.className = 'car-item col-md-4';
            carItem.innerHTML = `
                <div class="car-name">
                    ${car.nome}
                </div>
                <div class="car-body-category">
                    ${car.classe}
                </div>
                <div class="price">
                    €<p>${car.costo_per_giorno}</p><span>/day</span>
                </div>
                <div class="car-image">
                    <img src="${car.immagine || 'https://via.placeholder.com/150'}" alt="${car.nome}">
                </div>
                <div class="bottom-content">
                    <div class="car-feature">
                        <div class="feature-item">
                            <i class="fa-solid fa-gears"></i>
                            <span>${car.cambio}</span>
                        </div>
                        <div class="feature-item">
                            <i class="fa-solid fa-chair"></i>
                            <span>${car.posti} posti</span>
                        </div>
                        <div class="feature-item">
                            <i class="fa-solid fa-pump"></i>
                            <span>${car.consumo} KM/L</span>
                        </div>
                    </div>
                    <button onclick="apriPagina()" class="rent-button">
                        noleggia<i class="fa-solid fa-arrow-right"></i>
                    </button>
                </div>`;
            carListElement.appendChild(carItem);
        });
    }

    // Gestione della registrazione
    const registerForm = document.getElementById('register-form');
    registerForm.addEventListener('submit', event => {
        event.preventDefault();
        const formData = new FormData(registerForm);
        const registerParams = {
            nome: formData.get('nome'),
            cognome: formData.get('cognome'),
            email: formData.get('email'),
            password: formData.get('password')
        };
        fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(registerParams)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Registrazione avvenuta con successo.');
            } else {
                alert('Errore durante la registrazione.');
            }
        });
    });

    // Gestione del login
    const loginForm = document.getElementById('login-form');
    loginForm.addEventListener('submit', event => {
        event.preventDefault();
        const formData = new FormData(loginForm);
        const loginParams = {
            email: formData.get('email'),
            password: formData.get('password')
        };
        fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginParams)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Accesso effettuato con successo.');
            } else {
                alert('Credenziali non valide.');
            }
        });
    });
});

//auto admin disponibili

document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('.prenotazioni-admin tbody');

    fetch('/api/available-cars')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayAvailableCars(data.cars);
            } else {
                alert('Errore durante il recupero delle auto disponibili.');
            }
        });

    function displayAvailableCars(cars) {
        tableBody.innerHTML = '';
        cars.forEach(car => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${car.id_auto}</td>
                <td>${car.nome_auto}</td>
                <td>${car.classe}</td>
                <td>${car.costo_per_giorno}$</td>
                <td><button class="Elimina-admin">Elimina</button></td>`;
            tableBody.appendChild(row);
        });
    }
});

function logout() {
    fetch('/api/logout', {
        method: 'POST'
    }).then(response => {
        if (response.ok) {
            window.location.href = 'index.html';
        } else {
            showAlert('Errore durante il logout');
        }
    }).catch(error => {
        console.error('Errore durante il logout:', error);
    });
}

document.addEventListener('DOMContentLoaded', (event) => {
    fetch('/api/check-login')
        .then(response => response.json())
        .then(data => {
            const accountBox = document.getElementById('account-box');
            if (data.loggedIn) {
                accountBox.innerHTML = `
                    <button onclick="showAccount()" class="box account-bar">
                        <p>Account</p>
                        <i class="fa-solid fa-user"></i>
                    </button>
                    <button onclick="logout()" class="box login-bar">
                        <p>Esci</p>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                `;
                document.querySelector('a[href="Errore.html"]').href = "Noleggia.html";
                document.querySelector('a[href="Errore.html"]').href = "Catalogo.html";
                document.querySelector('a[href="Errore.html"]').href = "Recensione.html";
            } else {
                accountBox.innerHTML = `
                    <button onclick="window.location.href='login.html'" class="box login-bar">
                        <p>Login</p>
                        <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                    <button onclick="window.location.href='register.html'" class="box singup-bar">
                        <p>Registrati</p>
                        <i class="fa-solid fa-user-plus"></i>
                    </button>
                `;
            }
        })
        .catch(error => console.error('Errore:', error));
});

function showAccount() {
    fetch('/api/user-info')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'Account.html';
            } else {
                alert('Errore nel recupero delle informazioni utente.');
            }
        })
        .catch(error => {
            console.error('Errore:', error);
        });
}

    function hideAccount() {
        // Mostra il contenuto della home page
        document.querySelector('.home-page').style.display = 'block';
        document.querySelector('.how-it-works-page ').style.display = 'flex';
        document.querySelector('.milestone-page').style.display = 'block';
        document.querySelector('.service-page').style.display = 'block';
        // Nascondi la sezione dell'utente
        document.getElementById('user-section').style.display = 'none';
        document.getElementById('edit-user-section').style.display = 'none';
    }

    function deleteBooking(bookingId) {
        fetch(`/api/bookings/${bookingId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAccount(); // Ricarica le informazioni dell'utente per aggiornare la lista delle prenotazioni
            } else {
                alert('Errore durante la cancellazione della prenotazione.');
            }
        })
        .catch(error => {
            console.error('Errore:', error);
        });
    }

    function editUserInfo() {
        document.getElementById('user-section').style.display = 'none';
        document.getElementById('edit-user-section').style.display = 'block';

        fetch('/api/user-info')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('edit-email').value = data.user.email;
                    document.getElementById('edit-nome').value = data.user.nome;
                    document.getElementById('edit-cognome').value = data.user.cognome;
                }
            })
            .catch(error => {
                console.error('Errore nel recupero delle informazioni utente:', error);
            });
    }

    function cancelEdit() {
        // Nascondi la sezione di modifica utente
        document.getElementById('edit-user-section').style.display = 'none';

        // Mostra la sezione dell'utente
        document.getElementById('user-section').style.display = 'block';
    }

    document.getElementById('edit-user-form').addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(this);
        fetch('/api/user-info', {
            method: 'PUT',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAccount(); // Aggiorna le informazioni dell'utente
            } else {
                alert('Errore durante l\'aggiornamento delle informazioni utente.');
            }
        })
        .catch(error => {
            console.error('Errore:', error);
        });
    });

function showAlert(message) {
    document.getElementById('modal-message').innerText = message;
    document.getElementById('alert-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('alert-modal').style.display = 'none';
}

function showAccount() {
    fetch('/api/user-info')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'Account.html';
            } else {
                showAlert('Errore nel recupero delle informazioni utente.');
            }
        })
        .catch(error => {
            console.error('Errore:', error);
        });
}