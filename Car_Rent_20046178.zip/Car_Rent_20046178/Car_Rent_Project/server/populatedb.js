const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const db = new sqlite3.Database('./database.sqlite');

function hashPassword(password) {
    return new Promise((resolve, reject) => {
        bcrypt.hash(password, 10, (err, hash) => {
            if (err) {
                reject(err);
            } else {
                resolve(hash);
            }
        });
    });
}

db.serialize(() => {
    // Creazione delle tabelle
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            cognome TEXT NOT NULL,
            password TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS admins (
            email TEXT PRIMARY KEY,
            password TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS cars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            classe TEXT NOT NULL,
            costo_per_giorno REAL NOT NULL,
            consumo REAL NOT NULL,
            posti INTEGER NOT NULL,
            cambio TEXT NOT NULL,
            immagine TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT NOT NULL,
            car_id INTEGER NOT NULL,
            luogo_ritiro TEXT NOT NULL,
            data_ritiro DATE NOT NULL,
            ora_ritiro TIME NOT NULL,
            luogo_rilascio TEXT NOT NULL,
            data_rilascio DATE NOT NULL,
            ora_rilascio TIME NOT NULL,
            pagamento INTEGER NOT NULL,
            FOREIGN KEY (user_email) REFERENCES users (email),
            FOREIGN KEY (car_id) REFERENCES cars (id)
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS recensioni (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT NOT NULL,
            contenuto TEXT NOT NULL,
            FOREIGN KEY (user_email) REFERENCES users (email)
        )
    `);

    // Inserimento dati di esempio nella tabella 'users'
    const users = [
        { email: 'mario.rossi@example.com', nome: 'Mario', cognome: 'Rossi', password: 'password123' },
        { email: 'luigi.bianchi@example.com', nome: 'Luigi', cognome: 'Bianchi', password: 'password456' },
        { email: 'anna.verdi@example.com', nome: 'Anna', cognome: 'Verdi', password: 'password789' }
    ];

    const admins = [
        { email: 'admin1@example.com', password: 'adminpassword1' },
        { email: 'admin2@example.com', password: 'adminpassword2' }
    ];

    Promise.all(users.map(user =>
        hashPassword(user.password).then(hashedPassword =>
            new Promise((resolve, reject) => {
                db.run(`INSERT INTO users (email, nome, cognome, password) VALUES (?, ?, ?, ?)`, [user.email, user.nome, user.cognome, hashedPassword], (err) => {
                    if (err) {
                        console.error(`Errore durante l'inserimento dell'utente ${user.email}:`, err.message);
                        reject(err);
                    } else {
                        resolve();
                    }
                });
            })
        )
    )).then(() => {
        return Promise.all(admins.map(admin =>
            hashPassword(admin.password).then(hashedPassword =>
                new Promise((resolve, reject) => {
                    db.run(`INSERT INTO admins (email, password) VALUES (?, ?)`, [admin.email, hashedPassword], (err) => {
                        if (err) {
                            console.error(`Errore durante l'inserimento dell'admin ${admin.email}:`, err.message);
                            reject(err);
                        } else {
                            resolve();
                        }
                    });
                })
            )
        ));
    }).then(() => {
        const cars = [
            { nome: 'Fiat Panda', classe: 'City-Car', costo_per_giorno: 30, consumo: 15, posti: 5, cambio: 'Manuale', immagine: 'Panda-Dimensions-desktop-980x350.jpg' },
            
            { nome: 'Polo GTI', classe: 'City-Car', costo_per_giorno: 40, consumo: 12, posti: 5, cambio: 'Auto', immagine: 'vw-polopng.png' },
            
            { nome: 'Maybach Classe S', classe: 'Luxury', costo_per_giorno: 120, consumo: 20, posti: 4, cambio: 'Auto', immagine: 'mercedes s.png' },

            { nome: 'Audi R8', classe: 'Sportscar', costo_per_giorno: 300, consumo: 8, posti: 2, cambio: 'Auto', immagine: 'audi-r8-rwd.png' },

            { nome: 'BMW X5', classe: 'SUV', costo_per_giorno: 60, consumo: 15, posti: 5, cambio: 'Auto', immagine: '2024_bmw_x5_xdrive40i_ext_001_416.png' },

            { nome: 'AUDI A4', classe: 'Sedan', costo_per_giorno: 60.0, consumo: 15, posti: 5, cambio: 'Manuale', immagine: 'audi-a4.png' },

            { nome: 'Lamborghini', classe: 'Sportscar', costo_per_giorno: 400, consumo: 5, posti: 2, cambio: 'Auto', immagine: 'huracan.png' },

            { nome: 'Ferrari 812', classe: 'Sportscar', costo_per_giorno: 450, consumo: 8, posti: 2, cambio: 'Auto', immagine: 'ferrari 812.png' },

            { nome: 'Bugatti Chiron', classe: 'Hypercar', costo_per_giorno: 4500, consumo: 5, posti: 2, cambio: 'Auto', immagine: 'bugatti.jpg' },

            { nome: 'Mercedes-Benz C', classe: 'Sedan', costo_per_giorno: 70, consumo: 15, posti: 5, cambio: 'Manuale', immagine: 'mercedes-benz-c.png' },

            { nome: 'BMW M2', classe: 'Sportscar', costo_per_giorno: 150, consumo: 8, posti: 5, cambio: 'Manuale', immagine: 'M2png.png' },

            { nome: 'Ferrari 488', classe: 'Sportscar', costo_per_giorno: 500, consumo: 5, posti: 2, cambio: 'Auto', immagine: 'th.jpg' },
        ];

        cars.forEach(car => {
            db.run(`INSERT INTO cars (nome, classe, costo_per_giorno, consumo, posti, cambio, immagine) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [car.nome, car.classe, car.costo_per_giorno, car.consumo, car.posti, car.cambio, car.immagine], (err) => {
                if (err) {
                    console.error(`Errore durante l'inserimento dell'auto ${car.nome}:`, err.message);
                }
            });
        });

        const bookings = [
            { user_email: 'mario.rossi@example.com', car_id: 1, luogo_ritiro: 'Roma', data_ritiro: '2024-06-01', ora_ritiro: '09:00:00', luogo_rilascio: 'Milano', data_rilascio: '2024-06-10', ora_rilascio: '18:00:00', pagamento: 300 },
            { user_email: 'luigi.bianchi@example.com', car_id: 3, luogo_ritiro: 'Napoli', data_ritiro: '2024-06-05', ora_ritiro: '10:00:00', luogo_rilascio: 'Torino', data_rilascio: '2024-06-15', ora_rilascio: '16:00:00', pagamento: 1320 },
            { user_email: 'anna.verdi@example.com', car_id: 7, luogo_ritiro: 'Firenze', data_ritiro: '2024-06-10', ora_ritiro: '08:00:00', luogo_rilascio: 'Venezia', data_rilascio: '2024-06-20', ora_rilascio: '12:00:00', pagamento: 4400}
        ];

        bookings.forEach(booking => {
            db.run(`INSERT INTO bookings (user_email, car_id, luogo_ritiro, data_ritiro, ora_ritiro, luogo_rilascio, data_rilascio, ora_rilascio, pagamento) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [booking.user_email, booking.car_id, booking.luogo_ritiro, booking.data_ritiro, booking.ora_ritiro, booking.luogo_rilascio, booking.data_rilascio, booking.ora_rilascio, booking.pagamento], (err) => {
                if (err) {
                    console.error(`Errore durante l'inserimento della prenotazione per ${booking.user_email}:`, err.message);
                }
            });
        });

        const recensioni = [
            { user_email: 'mario.rossi@example.com', contenuto: 'Ottimo servizio!' },
            { user_email: 'luigi.bianchi@example.com', contenuto: 'Esperienza molto positiva!' },
            { user_email: 'anna.verdi@example.com', contenuto: 'Auto in ottime condizioni!' }
        ];

        recensioni.forEach(recensione => {
            db.run(`INSERT INTO recensioni (user_email, contenuto) VALUES (?, ?)`, [recensione.user_email, recensione.contenuto], (err) => {
                if (err) {
                    console.error(`Errore durante l'inserimento della recensione per ${recensione.user_email}:`, err.message);
                }
            });
        });

        // Chiudere il database solo dopo che tutte le operazioni sono state completate
        db.close((err) => {
            if (err) {
                return console.error(err.message);
            }
            console.log('Connessione al database chiusa.');
        });
    }).catch(err => {
        console.error('Errore durante il popolamento del database:', err.message);
        // Chiudere il database in caso di errore
        db.close((err) => {
            if (err) {
                return console.error(err.message);
            }
            console.log('Connessione al database chiusa.');
        });
    });
});
