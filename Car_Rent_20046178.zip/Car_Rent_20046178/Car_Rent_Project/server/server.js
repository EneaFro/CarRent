"use strict";

// Importazioni necessarie
const express = require('express');
const morgan = require('morgan');
const multer = require('multer');
const fs = require('fs');
const fileUpload = require('express-fileupload');

const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');
const flash = require('connect-flash');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt'); // Aggiunto bcrypt

const app = express();
const PORT = process.env.PORT || 3001;

// Creazione e configurazione del database


const db = new sqlite3.Database('./database.sqlite');
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            cognome TEXT NOT NULL,
            immagine TEXT,
            password TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS admins (
            email TEXT PRIMARY KEY,
            password TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS cars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            classe TEXT NOT NULL,
            costo_per_giorno REAL NOT NULL,
            consumo REAL NOT NULL,
            posti INTEGER NOT NULL,
            cambio TEXT NOT NULL,
            immagine TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT NOT NULL,
            car_id INTEGER NOT NULL,
            luogo_ritiro TEXT NOT NULL,
            data_ritiro DATE NOT NULL,
            ora_ritiro TIME NOT NULL,
            luogo_rilascio TEXT NOT NULL,
            data_rilascio DATE NOT NULL,
            ora_rilascio TIME NOT NULL,
            pagamento INTEGER NOT NULL,
            FOREIGN KEY (user_email) REFERENCES users (email),
            FOREIGN KEY (car_id) REFERENCES cars (id)
        )
    `);
});

// Middleware
app.use(flash());
app.use(morgan('tiny'));
app.use(express.json());
app.use(bodyParser.json());

app.use(fileUpload());
app.use(express.urlencoded({ extended: true }));

// Configura Express per servire i file statici dalla directory 'public'
app.use(express.static(path.join(__dirname, '..', 'public')));


// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, 'public', 'images'));
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});
const upload = multer({ dest: path.join(__dirname, 'public/images') });

// Inizializzazione della sessione
app.use(session({
    secret: 'frase segreta',
    resave: false,
    saveUninitialized: false 
}));
app.use(passport.initialize());
app.use(passport.session());

// Strategia di autenticazione per gli utenti
passport.use(new LocalStrategy(
    { usernameField: 'username', passwordField: 'password' },
    (username, password, done) => {
        db.get('SELECT * FROM users WHERE email = ?', [username], (err, user) => {
            if (err) {
                return done(err);
            }
            if (!user) {
                db.get('SELECT * FROM admins WHERE email = ?', [username], (err, admin) => {
                    if (err) {
                        return done(err);
                    }
                    if (!admin) {
                        return done(null, false, { message: 'Invalid username or password' });
                    }
                    bcrypt.compare(password, admin.password, (err, result) => {
                        if (err) {
                            return done(err);
                        }
                        if (result) {
                            admin.isAdmin = true;
                            return done(null, admin);
                        } else {
                            return done(null, false, { message: 'Invalid username or password' });
                        }
                    });
                });
            } else {
                bcrypt.compare(password, user.password, (err, result) => {
                    if (err) {
                        return done(err);
                    }
                    if (result) {
                        user.isAdmin = false;
                        return done(null, user);
                    } else {
                        return done(null, false, { message: 'Invalid username or password' });
                    }
                });
            }
        });
    }
));



passport.serializeUser((user, done) => {
    done(null, { email: user.email, isAdmin: user.isAdmin });
});

passport.deserializeUser((user, done) => {
    const { email, isAdmin } = user;
    if (isAdmin) {
        db.get('SELECT email, "admin" AS type FROM admins WHERE email = ?', [email], (err, admin) => {
            done(err, admin);
        });
    } else {
        db.get('SELECT email, "user" AS type FROM users WHERE email = ?', [email], (err, user) => {
            done(err, user);
        });
    }
});
//logout
app.post('/api/logout', (req, res) => {
    if (req.isAuthenticated()) {
        const email = req.user.email;
        req.logout((err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Errore durante il logout' });
            }
            console.log(`User logged out: ${email}`);
            res.json({ success: true });
        });
    } else {
        res.status(401).json({ success: false, message: 'Nessun utente autenticato' });
    }
});
//check-login
app.get('/api/check-login', (req, res) => {
    if (req.isAuthenticated()) {
        res.json({ loggedIn: true });
    } else {
        res.json({ loggedIn: false });
    }
});

// Endpoint per il login utente
app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            console.error('Authentication error:', err); // Log aggiuntivo
            return next(err);
        }
        if (!user) {
            console.log('Authentication failed:', info); // Log aggiuntivo
            return res.status(401).json({ success: false, message: 'Username o password errati' });
        }
        req.logIn(user, (err) => {
            if (err) {
                console.error('Login error:', err); // Log aggiuntivo
                return next(err);
            }
            const redirectUrl = user.isAdmin ? '/admin.html' : '/index.html';
            return res.status(200).json({ success: true, redirectUrl: redirectUrl });
        });
    })(req, res, next);
});

// Endpoint per registrare un utente
app.post('/api/register', (req, res) => {
    const { email, nome, cognome, password } = req.body;

    // Controllo se l'utente esiste già
    db.get(`SELECT email FROM users WHERE email = ?`, [email], (err, row) => {
        if (err) {
            console.error('Errore durante il controllo dell\'utente:', err);
            return res.json({ success: false, message: 'Errore durante il controllo dell\'utente.' });
        }
        if (row) {
            // L'utente esiste già
            return res.json({ success: false, message: 'L\'utente esiste già.' });
        } else {
            // Crittografare la password
            bcrypt.hash(password, 10, (err, hashedPassword) => {
                if (err) {
                    console.error('Errore durante la crittografia della password:', err);
                    return res.json({ success: false, message: 'Errore durante la registrazione dell\'utente.' });
                }
                // L'utente non esiste, procedere con l'inserimento
                db.run(`INSERT INTO users (email, nome, cognome, password) VALUES (?, ?, ?, ?)`, [email, nome, cognome, hashedPassword], function(err) {
                    if (err) {
                        console.error('Errore durante la registrazione dell\'utente:', err);
                        return res.json({ success: false, message: 'Errore durante la registrazione dell\'utente.' });
                    }
                    // Registrazione riuscita, effettuare il login dell'utente
                    req.logIn({ email: email }, function(err) {
                        if (err) {
                            console.error('Errore durante il login automatico dopo la registrazione:', err);
                            return res.json({ success: false, message: 'Errore durante il login automatico.' });
                        }
                        // Risposta di successo
                        return res.json({ success: true });
                    });
                });
            });
        }
    });
});

// Endpoint per ottenere le auto
app.get('/api/cars', (req, res) => {
    db.all(`SELECT * FROM cars`, [], (err, rows) => {
        if (err) {
            console.error('Errore durante il recupero delle auto:', err);
            return res.json({ success: false, message: 'Errore durante il recupero delle auto.' });
        }
        console.log('Auto recuperate:', rows); // Log dei dati delle macchine
        res.json({ success: true, cars: rows });
    });
});

// Endpoint per eliminare una macchina
app.delete('/api/cars/:id', (req, res) => {
    const carId = req.params.id;
    db.run(`DELETE FROM cars WHERE id = ?`, [carId], function(err) {
        if (err) {
            console.error('Errore durante l\'eliminazione della macchina:', err);
            return res.json({ success: false, message: 'Errore durante l\'eliminazione della macchina.' });
        }
        res.json({ success: true, message: 'Macchina eliminata con successo.' });
    });
});

// Endpoint per aggiungere una nuova macchina
app.post('/api/cars', (req, res) => {
    const { nome, classe, costo_per_giorno, consumo, posti, cambio } = req.body;

    if (!req.files || !req.files.immagine) {
        return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    let immagine = req.files.immagine;
    let uploadPath = __dirname + '/public/images/' + immagine.name;

    immagine.mv(uploadPath, function(err) {
        if (err) {
            console.error('Error while uploading image:', err);
            return res.status(500).send(err);
        }

        db.run(`INSERT INTO cars (nome, classe, costo_per_giorno, consumo, posti, cambio, immagine) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [nome, classe, costo_per_giorno, consumo, posti, cambio, immagine.name],
            function(err) {
                if (err) {
                    console.error('Error while adding car:', err);
                    return res.json({ success: false, message: 'Error while adding car.' });
                }
                res.json({ success: true, message: 'Car added successfully.', car: { id: this.lastID, nome, classe, costo_per_giorno, consumo, posti, cambio, immagine: immagine.name } });
            }
        );
    });
});





// Configurazione per servire i file statici
app.use('/images', express.static(path.join(__dirname, '/public/images')));


// Endpoint per ottenere gli admin
app.get('/api/admins', (req, res) => {
    db.all(`SELECT * FROM admins`, [], (err, rows) => {
        if (err) {
            console.error('Errore durante il recupero degli admin:', err);
            return res.json({ success: false, message: 'Errore durante il recupero degli admin.' });
        }
        res.json({ success: true, admins: rows });
    });
});

// Endpoint per aggiungere un nuovo admin
app.post('/api/admins', (req, res) => {
    const { email, password } = req.body;
    // Crittografare la password
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            console.error('Errore durante la crittografia della password:', err);
            return res.json({ success: false, message: 'Errore durante l\'aggiunta dell\'admin.' });
        }
        db.run(`INSERT INTO admins (email, password) VALUES (?, ?)`, [email, hashedPassword], function(err) {
            if (err) {
                console.error('Errore durante l\'aggiunta dell\'admin:', err);
                return res.json({ success: false, message: 'Errore durante l\'aggiunta dell\'admin.' });
            }
            res.json({ success: true, message: 'Admin aggiunto con successo.' });
        });
    });
});

// Endpoint per eliminare un admin
app.delete('/api/admins/:email', (req, res) => {
    const email = req.params.email;
    db.run(`DELETE FROM admins WHERE email = ?`, [email], function(err) {
        if (err) {
            console.error('Errore durante l\'eliminazione dell\'admin:', err);
            return res.json({ success: false, message: 'Errore durante l\'eliminazione dell\'admin.' });
        }
        res.json({ success: true, message: 'Admin eliminato con successo.' });
    });
});

// Endpoint per ottenere le prenotazioni
app.get('/api/bookings', (req, res) => {
    db.all(`SELECT * FROM bookings`, [], (err, rows) => {
        if (err) {
            console.error('Errore durante il recupero delle prenotazioni:', err);
            return res.json({ success: false, message: 'Errore durante il recupero delle prenotazioni.' });
        }
        res.json({ success: true, bookings: rows });
    });
})

// Endpoint per prenotare un'auto
app.post('/api/book-car', (req, res) => {
    if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: 'User not authenticated' });
    }

    const { car_id, luogo_ritiro, data_ritiro, ora_ritiro, luogo_rilascio, data_rilascio, ora_rilascio } = req.body;
    const user_email = req.user.email;

    // Calcolare il numero di giorni tra data_ritiro e data_rilascio
    const dateRitiro = new Date(data_ritiro);
    const dateRilascio = new Date(data_rilascio);
    const timeDifference = Math.abs(dateRilascio - dateRitiro);
    const numberOfDays = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));

    // Ottenere il costo per giorno della macchina
    db.get('SELECT costo_per_giorno FROM cars WHERE id = ?', [car_id], (err, car) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Errore durante il recupero del costo della macchina.' });
        }

        const pagamento = car.costo_per_giorno * numberOfDays;

        const query = `
            INSERT INTO bookings (user_email, car_id, luogo_ritiro, data_ritiro, ora_ritiro, luogo_rilascio, data_rilascio, ora_rilascio, pagamento)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        db.run(query, [user_email, car_id, luogo_ritiro, data_ritiro, ora_ritiro, luogo_rilascio, data_rilascio, ora_rilascio, pagamento], function(err) {
            if (err) {
                res.status(500).json({ success: false, message: 'Errore durante la prenotazione della macchina.' });
            } else {
                res.json({ success: true, message: 'Prenotazione effettuata con successo.' });
            }
        });
    });
});

app.get('/api/cars/:id', (req, res) => {
    const carId = req.params.id;
    db.get('SELECT * FROM cars WHERE id = ?', [carId], (err, row) => {
        if (err) {
            res.status(500).json({ success: false, message: 'Errore durante il recupero della macchina.' });
        } else {
            res.json(row);
        }
    });
});



// Filtri auto
app.get('/api/filter-cars', (req, res) => {
    const { type, capacity, transmission, pickUpDate, pickUpTime, dropOffDate, dropOffTime } = req.query;

    const pickUpDateTime = `${pickUpDate} ${pickUpTime}`;
    const dropOffDateTime = `${dropOffDate} ${dropOffTime}`;

    let query = `
        SELECT * FROM cars WHERE id NOT IN (
            SELECT car_id FROM bookings WHERE
            (? < datetime(data_rilascio || ' ' || ora_rilascio) AND ? > datetime(data_ritiro || ' ' || ora_ritiro))
        )
    `;

    if (type) {
        query += " AND classe IN (" + type.split(',').map(t => `'${t}'`).join(',') + ")";
    }
    if (capacity) {
        query += " AND posti IN (" + capacity.split(',').map(c => parseInt(c)).join(',') + ")";
    }
    if (transmission) {
        query += " AND cambio IN (" + transmission.split(',').map(tr => `'${tr}'`).join(',') + ")";
    }

    db.all(query, [pickUpDateTime, dropOffDateTime], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

//endpoint per eliminare una prenotazione
app.delete('/api/bookings/:id', (req, res) => {
    const bookingId = req.params.id;
    db.run('DELETE FROM bookings WHERE id = ?', bookingId, function(err) {
        if (err) {
            res.status(500).json({ success: false, message: 'Errore durante la cancellazione della prenotazione.' });
        } else {
            res.json({ success: true, message: 'Prenotazione cancellata con successo.' });
        }
    });
});

// Endpoint per aggiornare le informazioni dell'utente
app.put('/api/user-info', (req, res) => {
    if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: 'Utente non autenticato.' });
    }
    const { email, nome, cognome } = req.body;
    const userEmail = req.user.email;

    db.run('UPDATE users SET email = ?, nome = ?, cognome = ? WHERE email = ?', [email, nome, cognome, userEmail], function (err) {
        if (err) {
            console.error('Errore durante l\'aggiornamento delle informazioni utente:', err);
            return res.status(500).json({ success: false, message: 'Errore durante l\'aggiornamento delle informazioni utente.' });
        }
        res.json({ success: true, message: 'Informazioni utente aggiornate con successo.' });
    });
});


app.get('/api/users', (req, res) => {
    db.all(`SELECT * FROM users`, [], (err, rows) => {
        if (err) {
            console.error('Errore durante il recupero degli utenti:', err);
            return res.json({ success: false, message: 'Errore durante il recupero degli utenti.' });
        }
        res.json({ success: true, users: rows });
    });
});

// Endpoint per ottenere le informazioni dell'utente autenticato
app.get('/Account.html', (req, res, next) => {
    if (!req.isAuthenticated()) {
        return res.redirect('/login.html');
    }
    next();
});
//Endpoint per ottenere informazioni utente
app.get('/api/user-info', (req, res) => {
    if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: 'Utente non autenticato.' });
    }
    const email = req.user.email;
    db.get('SELECT email, nome, cognome FROM users WHERE email = ?', email, (err, user) => {
        if (err || !user) {
            return res.status(500).json({ success: false, message: 'Errore durante il recupero delle informazioni utente.' });
        }
        db.all('SELECT * FROM bookings WHERE user_email = ?', email, (err, bookings) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Errore durante il recupero delle prenotazioni.' });
            }
            res.json({ success: true, user, bookings });
        });
    });
});


// Ricerca auto
app.post('/api/search-cars', (req, res) => {
    const { pickUpDate, pickUpTime, dropOffDate, dropOffTime, pickUpAddress, dropOffAddress } = req.body;

    const pickUpDateTime = `${pickUpDate} ${pickUpTime}`;
    const dropOffDateTime = `${dropOffDate} ${dropOffTime}`;

    const query = `
        SELECT * FROM cars WHERE id NOT IN (
            SELECT car_id FROM bookings WHERE
            (? < datetime(data_rilascio || ' ' || ora_rilascio) AND ? > datetime(data_ritiro || ' ' || ora_ritiro))
        )
    `;

    db.all(query, [pickUpDateTime, dropOffDateTime], (err, rows) => {
        if (err) {
            res.status(500).json({ success: false, message: 'Errore durante la ricerca delle auto.' });
        } else {
            res.json({ success: true, cars: rows });
        }
    });
    
});
//gestione barra di ricerca testuale
app.get('/api/search-carss', (req, res) => {
    const { query } = req.query;
    const sql = `SELECT * FROM cars WHERE nome LIKE ? OR classe LIKE ? OR cambio LIKE ?`;
    db.all(sql, [`%${query}%`, `%${query}%`, `%${query}%`], (err, cars) => {
        if (err) {
            console.error('Error querying cars:', err);
            res.status(500).json({ success: false, message: 'Database query error' });
        } else {
            res.json({ success: true, cars: cars });
        }
    });
});

// Endpoint per ottenere tutte le recensioni
app.get('/api/reviews', (req, res) => {
    db.all('SELECT * FROM recensioni', [], (err, rows) => {
        if (err) {
            res.status(500).json({ success: false, message: 'Errore durante il recupero delle recensioni.' });
        } else {
            res.json({ success: true, reviews: rows });
        }
    });
});

// Endpoint per aggiungere una nuova recensione
app.post('/api/reviews', (req, res) => {
    const { user_email, contenuto } = req.body;

    const query = 'INSERT INTO recensioni (user_email, contenuto) VALUES (?, ?)';
    db.run(query, [user_email, contenuto], function(err) {
        if (err) {
            res.status(500).json({ success: false, message: 'Errore durante l\'aggiunta della recensione.' });
        } else {
            res.json({ success: true, message: 'Recensione aggiunta con successo.' });
        }
    });
});
//verifica disponibilità auto
app.post('/api/check-availability', (req, res) => {
    const { car_id, luogo_ritiro, data_ritiro, ora_ritiro, luogo_rilascio, data_rilascio, ora_rilascio } = req.body;

    const checkAvailabilityQuery = `
        SELECT * FROM bookings
        WHERE car_id = ? AND (
            (data_ritiro <= ? AND data_rilascio >= ?) OR
            (data_ritiro <= ? AND data_rilascio >= ?)
        )
    `;

    db.all(checkAvailabilityQuery, [car_id, data_ritiro, data_ritiro, data_rilascio, data_rilascio], (err, rows) => {
        if (err) {
            console.error('Errore durante la verifica della disponibilità:', err);
            return res.json({ available: false, message: 'Errore durante la verifica della disponibilità.' });
        }

        if (rows.length > 0) {
            return res.json({ available: false, message: 'L\'auto non è disponibile per le date selezionate.' });
        }

        res.json({ available: true });
    });
});

app.get('/api/get-car', (req, res) => {
    const carId = req.query.id;

    db.get('SELECT * FROM cars WHERE id = ?', [carId], (err, car) => {
        if (err) {
            console.error('Errore durante il recupero dei dettagli dell\'auto:', err);
            return res.json({ success: false, message: 'Errore durante il recupero dei dettagli dell\'auto.' });
        }

        res.json({ success: true, car });
    });
});




// Servire il file index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Avvio del server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
