const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.sqlite');

db.serialize(() => {
    db.each("SELECT email, nome, cognome FROM users", (err, row) => {
        if (err) {
            console.error(err.message);
        }
        console.log(row.email + "\t" + row.nome + "\t" + row.cognome);
    });
});

db.close();